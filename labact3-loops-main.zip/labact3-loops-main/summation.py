n = int(input("Enter a number: "))

sum = 0
for i in range(1, n + 1):
    sum += i

print("Formula: 1+2+3+4")
print("Output: ", sum)
